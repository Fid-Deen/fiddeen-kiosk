globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/a7c3a0ff34d1457c.js",
      "static/chunks/turbopack-7885bed569921ecc.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/a7c3a0ff34d1457c.js",
      "static/chunks/turbopack-597d433b233f3272.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/fd2be76e6b40ca47.js",
    "static/chunks/34c4658583b69a91.js",
    "static/chunks/569f8ca39997ccda.js",
    "static/chunks/turbopack-dd51e4634d249158.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];