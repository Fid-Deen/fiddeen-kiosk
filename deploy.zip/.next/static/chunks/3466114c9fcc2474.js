__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/a7c3a0ff34d1457c.js",
  "static/chunks/turbopack-7885bed569921ecc.js"
])
