var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/generate/route.js")
R.c("server/chunks/[root-of-the-server]__a9c0bd83._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.m(86500)
R.m(3476)
module.exports=R.m(3476).exports
